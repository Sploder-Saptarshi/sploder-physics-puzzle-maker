package ;
import cx.Algorithm;
import cx.Allocator;
import cx.FastList;
import cx.MixList;
import nape.callbacks.Callback;
import nape.callbacks.Callbackable;
import nape.callbacks.CbType;
import nape.Config;
import nape.Const;
import nape.constraint.Anchor;
import nape.constraint.ClassicCons;
import nape.constraint.Constraint;
import nape.constraint.DampedRotarySpring;
import nape.constraint.DampedSpring;
import nape.constraint.GearJoint;
import nape.constraint.GrooveJoint;
import nape.constraint.MPConsPair;
import nape.constraint.MultiPinJoint;
import nape.constraint.MultiSlideJoint;
import nape.constraint.PinJoint;
import nape.constraint.PivotJoint;
import nape.constraint.PulleyJoint;
import nape.constraint.RotaryLimitJoint;
import nape.constraint.SimpleMotor;
import nape.constraint.SlideJoint;
import nape.constraint.TwoConstraint;
import nape.dynamics.Arbiter;
import nape.dynamics.Collide;
import nape.dynamics.Contact;
import nape.dynamics.GroupArb;
import nape.dynamics.ObjArb;
import nape.dynamics.SubArbiters;
import nape.geom.AABB;
import nape.geom.Axis;
import nape.geom.Geom;
import nape.geom.GeomPoly;
import nape.geom.GeomVert;
import nape.geom.Ray;
import nape.geom.RayResult;
import nape.geom.Vec2;
import nape.geom.VecMath;
import nape.phys.Body;
import nape.phys.Group;
import nape.phys.Material;
import nape.phys.Particle;
import nape.phys.PhysObj;
import nape.phys.Properties;
import nape.shape.Circle;
import nape.shape.Polygon;
import nape.shape.Shape;
import nape.space.BruteSpace;
import nape.space.Space;
import nape.space.UniformDynamicSpace;
import nape.space.UniformSleepSpace;
import nape.space.UniformSpace;
import nape.util.Array2;
import nape.util.FastMath;
import nape.util.FixedStep;
import nape.util.IdRef;
import nape.util.Tools;
import cx.CxFastNode_PhysObj;
import cx.CxFastList_PhysObj;
import cx.CxFastNode_MPConsPair;
import cx.CxFastList_MPConsPair;
import cx.CxFastNode_Anchor;
import cx.CxFastList_Anchor;
import cx.CxFastNode_Contact;
import cx.CxFastList_Contact;
import cx.CxFastNode_ObjArb;
import cx.CxFastList_ObjArb;
import cx.CxFastNode_Arbiter;
import cx.CxFastList_Arbiter;
import cx.CxFastNode_Arbiter_false_false_true_true_Shape_Shape;
import cx.CxFastList_Arbiter_false_false_true_true_Shape_Shape;
import cx.CxFastNode_Arbiter_false_false_true_false_Shape_Particle;
import cx.CxFastList_Arbiter_false_false_true_false_Shape_Particle;
import cx.CxFastNode_Arbiter_true_true_true_true_Shape_Shape;
import cx.CxFastList_Arbiter_true_true_true_true_Shape_Shape;
import cx.CxFastNode_Arbiter_true_true_true_false_Shape_Particle;
import cx.CxFastList_Arbiter_true_true_true_false_Shape_Particle;
import cx.CxFastNode_GeomPoly;
import cx.CxFastList_GeomPoly;
import cx.CxFastNode_UniformSleepCell;
import cx.CxFastList_UniformSleepCell;
import cx.CxFastNode_Constraint;
import cx.CxFastList_Constraint;
import cx.CxFastNode_Shape;
import cx.CxFastList_Shape;
import cx.CxFastNode_Body;
import cx.CxFastList_Body;
import cx.CxFastNode_Particle;
import cx.CxFastList_Particle;
import cx.CxFastNode_Group;
import cx.CxFastList_Group;
import cx.CxFastNode_Properties;
import cx.CxFastList_Properties;
import cx.CxFastNode_Callback;
import cx.CxFastAllocList_Callback;
import cx.CxFastNode_UniformCell;
import cx.CxFastList_UniformCell;






class DummyNapeMain {
	static function main() {}
}


